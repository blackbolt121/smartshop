package com.smartshop.smartshop.DTO;

public record ProductoDTO(String id, String name, double price, String imageUrl) {}
